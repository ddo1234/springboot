import VueRouter from 'vue-router';

const routes =[
    //登录页面
    {
        path:'',
        name:'login',
        component:()=>import('../components/Login')
    },
    //登录成功跳转到主页
    {
        path:'/index',
        name:'index',
        component:()=>import('../components/index')
    }

]
const router = new VueRouter({
    //history目的是为了消除待会路由路径的＃号，非必要。
    mode:'history',
    routes
})
export default router;